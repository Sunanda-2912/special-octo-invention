package com.product.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class ProductDto {

	private String productId ;
	private String productName;
	private String productCategory;
	private Timestamp manufactureDate;
	
	private Timestamp expiryDate;
    private BigDecimal price;
    
    
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public Timestamp getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Timestamp manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public Timestamp getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "ProductDto [productId=" + productId + ", productCategory=" + productCategory + ", manufactureDate="
				+ manufactureDate + ", expiryDate=" + expiryDate + "]";
	}
    
}
