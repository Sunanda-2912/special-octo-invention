package com.product.dao;

public class DaoFactory {
	
private static ProductDaoIntf products;
static {
	products = new ProductDaoImpl();
}
public static  ProductDaoIntf getProductDet() {
	return products;
}
}
