package com.product.dao;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.product.bean.Product;
import com.product.bean.ProductPrice;
import com.product.dto.ProductDto;
import com.product.util.DbUtil;

public class ProductDaoImpl implements ProductDaoIntf {

	@Override
	public int insertProductDet(ProductDto dto) {

		Connection con = null;
		PreparedStatement ps = null;
		int insertProductDet = 0;

		String query = "INSERT INTO product(productId,productName, productCategory, manufactureDate,expiryDate) values (?,?,?,?,?)";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, dto.getProductId());
			ps.setString(2, dto.getProductName());
			ps.setString(3, dto.getProductCategory());
			ps.setTimestamp(4, dto.getManufactureDate());
			ps.setTimestamp(5, dto.getExpiryDate());

			insertProductDet = ps.executeUpdate();

			if (insertProductDet != 0) {
				System.out.println("insertion successfull");
			} else {
				System.out.println("insertion failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps);
		}

		return insertProductDet;
	}

	@Override
	public List<ProductDto> getProductNameAndCategory(ProductDto dto) {

		List<ProductDto> products = new ArrayList();
		ProductDto productDto = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int insertProductDet = 0;

		String query = "Select productId,productName,productCategory,manufactureDate,expiryDate From product Where productName=? And productCategory=?";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, dto.getProductName());
			ps.setString(2, dto.getProductCategory());
			rs = ps.executeQuery();

			while (rs.next()) {
				String productId = rs.getString("productId");
				String name = rs.getString("productName");
				String category = rs.getString("productCategory");
				Timestamp mfgDate = rs.getTimestamp("manufactureDate");
				Timestamp expDate = rs.getTimestamp("expiryDate");

				productDto = new ProductDto();
				productDto.setProductId(productId);
				productDto.setProductName(name);
				productDto.setProductCategory(category);
				productDto.setManufactureDate(mfgDate);
				productDto.setExpiryDate(expDate);

				products.add(productDto);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps);
		}

		return products;
	}

	@Override
	public int insertProductPrice(ProductDto dto) {
		Connection con = null;
		PreparedStatement ps = null;
		int insertProductPrice = 0;
		String query = "INSERT INTO productprice (productId,price) values (?,?)";

		try {
			con = DbUtil.getConnection();

			ps = con.prepareStatement(query);
			ps.setString(1, dto.getProductId());
			ps.setBigDecimal(2, dto.getPrice());

			insertProductPrice = ps.executeUpdate();
			if (insertProductPrice != 0) {
				System.out.println("insertion successfull");
			} else {
				System.out.println("insertion failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps);
		}

		return insertProductPrice;
	}

	@Override
	public List<Product> getProductDetail(String productName) {
		List<Product> products = new ArrayList();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Product product = null;

		String query = "Select productId,productCategory,manufactureDate,expiryDate From product Where productName=? ";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, productName);// Select productId,productCategory,manufactureDate,expiryDate From product
											// Where productName=product1
			rs = ps.executeQuery();

			while (rs.next()) {
				String prodId = rs.getString("productId");
				String prodCate = rs.getString("productCategory");
				Timestamp mfDate = rs.getTimestamp("manufactureDate");
				Timestamp expDate = rs.getTimestamp("expiryDate");

				product = new Product();
				product.setProductId(prodId);
				product.setProductCategory(prodCate);
				product.setManufactureDate(mfDate);
				product.setExpiryDate(expDate);

				products.add(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}
		return products;
	}

	@Override
	public List<Product> getProductNameAndCategory(String productName, String productCategory) {

		List<Product> products = new ArrayList();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Product product = null;

		String query = "Select productId,productName,productCategory,manufactureDate,expiryDate From product Where productName=? And productCategory=?";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, productName);
			ps.setString(2, productCategory);
			rs = ps.executeQuery();

			while (rs.next()) {
				String productId = rs.getString("productId");
				String name = rs.getString("productName");
				String category = rs.getString("productCategory");
				Timestamp mfgDate = rs.getTimestamp("manufactureDate");
				Timestamp expDate = rs.getTimestamp("expiryDate");

				product = new Product();
				product.setProductId(productId);
				product.setProductName(productName);
				product.setProductCategory(productCategory);
				product.setManufactureDate(mfgDate);
				product.setExpiryDate(expDate);

				products.add(product);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}
		return products;
	}

	@Override
	public List<Product> getProducts(String firstId, String lastId) {

		List<Product> products = new ArrayList();
		Product product = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM product WHERE CAST(productId AS UNSIGNED) BETWEEN ? AND ? ORDER BY CAST(productId AS UNSIGNED) DESC";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, firstId);
			ps.setString(2, lastId);
			rs = ps.executeQuery();
			while (rs.next()) {
				String productId = rs.getString("productId");
				String name = rs.getString("productName");
				String category = rs.getString("productCategory");
				Timestamp mfgDate = rs.getTimestamp("manufactureDate");
				Timestamp expDate = rs.getTimestamp("expiryDate");

				product = new Product();
				product.setProductId(productId);
				product.setProductName(name);
				product.setProductCategory(category);
				product.setManufactureDate(mfgDate);
				product.setExpiryDate(expDate);

				products.add(product);
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}
		return products;
	}

	@Override
	public List<ProductDto> getProductsByMfgDate(Timestamp startTime, Timestamp endTime) {
		List<ProductDto> products = new ArrayList<>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM product WHERE manufactureDate BETWEEN ? AND ?";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setTimestamp(1, startTime);
			ps.setTimestamp(2, endTime);
			rs = ps.executeQuery();

			while (rs.next()) {
				ProductDto dto = new ProductDto();
				dto.setProductId(rs.getString("productId"));
				dto.setProductName(rs.getString("productName"));
				dto.setProductCategory(rs.getString("productCategory"));
				dto.setManufactureDate(rs.getTimestamp("manufactureDate"));
				dto.setExpiryDate(rs.getTimestamp("expiryDate"));

				products.add(dto);
			}
			System.out.println(products);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}

		return products;
	}

	@Override
	public List<ProductDto> getProduct(Timestamp startTime, Timestamp endTime) {
		List<ProductDto> products = new ArrayList<>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM product WHERE expiryDate <=?";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setTimestamp(1, endTime);
			rs = ps.executeQuery();

			while (rs.next()) {
				ProductDto dto = new ProductDto();
				dto.setProductId(rs.getString("productId"));
				dto.setProductName(rs.getString("productName"));
				dto.setProductCategory(rs.getString("productCategory"));
				dto.setManufactureDate(rs.getTimestamp("manufactureDate"));
				dto.setExpiryDate(rs.getTimestamp("expiryDate"));

				products.add(dto);
			}
			System.out.println(products);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}

		return products;
	}

	@Override
	public List<ProductDto> getProducts(String productName, String productCategory, Timestamp mfgStartTime,
			Timestamp mgfEndTime, Timestamp expStartTime, Timestamp expEndTime) {

		List<ProductDto> products = new ArrayList<>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuilder queryBuilder = new StringBuilder("SELECT * FROM Product WHERE 1=1");

		// Append conditions to the query based on provided parameters
		if (productName != null && !productName.isEmpty()) {
			queryBuilder.append(" AND productName = ?");
		}
		if (productCategory != null && !productCategory.isEmpty()) {
			queryBuilder.append(" AND productCategory = ?");
		}
		if (mfgStartTime != null && mgfEndTime != null) {
			queryBuilder.append(" AND manufactureDate BETWEEN ? AND ?");
		}
		if ( expStartTime!=null && expEndTime != null ) {
			queryBuilder.append(" AND expiryDate BETWEEN ? And ?");
		}

		try {
			// Initialize connection before preparing statement
			con = DbUtil.getConnection();

			// Prepare the statement after constructing the final query
			ps = con.prepareStatement(queryBuilder.toString());

			// Set parameters based on the query conditions
			int index = 1;
			if (productName != null && !productName.isEmpty()) {
				ps.setString(index++, productName);
			}
			if (productCategory != null && !productCategory.isEmpty()) {
				ps.setString(index++, productCategory);
			}
			if (mfgStartTime != null && expEndTime != null) {
				ps.setTimestamp(index++, mfgStartTime);
				ps.setTimestamp(index++, expEndTime);
			}
			if (expStartTime !=null &&  expEndTime != null) {
				ps.setTimestamp(index++, expStartTime);
				ps.setTimestamp(index++, expEndTime);
			}

			rs = ps.executeQuery();

			while (rs.next()) {
				ProductDto prod = new ProductDto();
				prod.setProductId(rs.getString("productId"));
				prod.setProductName(rs.getString("productName"));
				prod.setProductCategory(rs.getString("productCategory"));
				prod.setManufactureDate(rs.getTimestamp("manufactureDate"));
				prod.setExpiryDate(rs.getTimestamp("expiryDate"));

				products.add(prod);
			}
			System.out.println(products);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}
		return products;
	}

	@Override
	public List<ProductDto> getAllProducts() {

		List<ProductDto> products = new ArrayList<ProductDto>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "Select * From product";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				ProductDto prod = new ProductDto();
				prod.setProductId(rs.getString("productId"));
				prod.setProductName(rs.getString("productName"));
				prod.setProductCategory(rs.getString("productCategory"));
				prod.setManufactureDate(rs.getTimestamp("manufactureDate"));
				prod.setExpiryDate(rs.getTimestamp("expiryDate"));

				products.add(prod);
			}
			System.out.println(products);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbUtil.close(con, ps, rs);
		}
		return products;
	}

}
