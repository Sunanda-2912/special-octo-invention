package com.product.dao;

import java.sql.Timestamp;
import java.util.List;

import com.mysql.cj.x.protobuf.MysqlxCrud.Insert;
import com.product.bean.Product;
import com.product.bean.ProductPrice;
import com.product.dto.ProductDto;

public interface ProductDaoIntf {

	public int insertProductDet(ProductDto dto);
	public int insertProductPrice(ProductDto dto);
	public List<Product> getProductDetail(String productName);
	public List<Product> getProductNameAndCategory(String productName, String productCategory);
	public List<ProductDto> getProductNameAndCategory(ProductDto productDto);
	public List<Product> getProducts(String firstId , String lastId);
    public List<ProductDto> getProductsByMfgDate(Timestamp startTime, Timestamp endTime) ;
    public List<ProductDto> getProduct(Timestamp startTime, Timestamp endTime);
    public List<ProductDto> getProducts(String productName,String productCategory, Timestamp startTime, Timestamp endTime,Timestamp startTime1, Timestamp endTime2 );
    public List<ProductDto> getAllProducts();
	
}
