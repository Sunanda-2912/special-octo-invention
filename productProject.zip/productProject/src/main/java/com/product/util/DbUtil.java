package com.product.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbUtil {
	private static final String DriverName="com.mysql.cj.jdbc.Driver";
	private static final String Url= "jdbc:mysql://localhost:3306/product?useSSL=false";
	private static final String userName= "root"; 
	private static final String password= "Sunanda@123";

	static {
		try {
			Class.forName(DriverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			con= DriverManager.getConnection(Url,userName,password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public static void close(Connection con, PreparedStatement ps, ResultSet rs) {
		try {
			if(con!=null) {
				con.close();
			}
			if(ps!=null) {
				ps.close();
			}
			if(rs!=null) {
				rs.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void close(Connection con, PreparedStatement ps) {
		try {
			if(con!=null) {
				con.close();
			}
			if(ps!=null) {
				ps.close();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
