package com.product.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class Product implements Serializable{

	private String productId ;
	private String productName;
	private String productCategory;
	private Timestamp manufactureDate;
	private Timestamp expiryDate;
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public Timestamp getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Timestamp mfDate) {
		this.manufactureDate = mfDate;
	}
	public Timestamp getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ",  productCategory="
				+ productCategory + ", manufactureDate=" + manufactureDate + ", expiryDate=" + expiryDate + "]";
	}
	
	
	
}
