package com.product.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProductPrice implements Serializable{

	private Integer priceId;
	private String productid;
    private BigDecimal price;
	public Integer getPriceId() {
		return priceId;
	}
	public void setPriceId(Integer priceId) {
		this.priceId = priceId;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "ProductPrice [ price=" + price + "]";
	}
    
    
}
