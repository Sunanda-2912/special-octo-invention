package com.product.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Timestamp;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.product.dto.ProductDto;
import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class InsertProductServlet extends HttpServlet {
    private static ProductServiceIntf service = ServiceFactory.getProducts();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String jsonResponse = "";
        PrintWriter writer = resp.getWriter();
        JSONArray validateValue = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        StringBuilder sb = new StringBuilder();
        String contentType = req.getContentType();

        if (contentType == null || !contentType.equals("application/json")) {
            jsonObject.put("error", "Content type must be application/json");
            writer.print(jsonObject.toJSONString());
            writer.flush();
            writer.close();
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }

        BufferedReader reader = req.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        JSONParser parser = new JSONParser();

        try {
            JSONObject jsonSb = (JSONObject) parser.parse(sb.toString());

            String productId = (String) jsonSb.get("productId");
            String productName = (String) jsonSb.get("productName");
            String productCategory = (String) jsonSb.get("productCategory");
            String mfd = (String) jsonSb.get("manufactureDate");
            String expDt = (String) jsonSb.get("expiryDate");
            String price = (String) jsonSb.get("price");

            if (productId == null || productId.isEmpty()) {
                jsonObject = new JSONObject();
                jsonObject.put("prodId", "Product ID can't be empty");
                validateValue.add(jsonObject);
            }
            if (productName == null || productName.isEmpty()) {
                jsonObject = new JSONObject();
                jsonObject.put("Name", "Name can't be empty");
                validateValue.add(jsonObject);
            }
            if (productCategory == null || productCategory.isEmpty()) {
                jsonObject = new JSONObject();
                jsonObject.put("productCategory", "Category can't be empty");
                validateValue.add(jsonObject);
            }

            Timestamp manufactureDt = null;
            if (mfd == null || mfd.isEmpty()) {
                jsonObject = new JSONObject();
                jsonObject.put("mfd", "Manufacture date can't be empty");
                validateValue.add(jsonObject);
            } else {
                manufactureDt = Timestamp.valueOf(mfd);
            }

            Timestamp expiryDt = null;
            if (expDt == null || expDt.isEmpty()) {
                jsonObject = new JSONObject();
                jsonObject.put("expDt", "Expiry date can't be empty");
                validateValue.add(jsonObject);
            } else {
                expiryDt = Timestamp.valueOf(expDt);
            }

            BigDecimal rate = null;
            if (price == null || price.isEmpty()) {
                jsonObject = new JSONObject();
                jsonObject.put("price", "Price can't be empty");
                validateValue.add(jsonObject);
            } else {
                rate = new BigDecimal(price);
            }

            if (!validateValue.isEmpty()) {
                jsonResponse = validateValue.toJSONString();
                writer.write(jsonResponse);
                writer.flush();
                writer.close();
                return;
            }

            ProductDto productDto = new ProductDto();
            productDto.setProductId(productId);
            productDto.setProductName(productName);
            productDto.setProductCategory(productCategory);
            productDto.setManufactureDate(manufactureDt);
            productDto.setExpiryDate(expiryDt);
            productDto.setPrice(rate);

            jsonResponse = service.insertProductDet(productDto);
            System.out.println("jsonResponse: " + jsonResponse);
            if (!jsonResponse.isEmpty()) {
                writer.write(jsonResponse);
            }
        } catch (ParseException e) {
            jsonObject.put("error", e.getMessage());
            e.printStackTrace();
            writer.print(jsonObject.toJSONString());
        } catch (Exception e) {
            jsonObject.put("error", e.getMessage());
            e.printStackTrace();
            writer.print(jsonObject.toJSONString());
        } finally {
            writer.flush();
            writer.close();
        }
    }
}
