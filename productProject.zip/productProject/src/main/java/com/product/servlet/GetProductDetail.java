package com.product.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.json.simple.JSONObject;

import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GetProductDetail extends HttpServlet{
	private static ProductServiceIntf service = ServiceFactory.getProducts();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		JSONObject jsonObject = null;
		String productName= req.getParameter("productName");
		String jsonResponse= "";
		resp.setContentType("application/json");
		
		if(productName ==null || productName.isEmpty()) {
			jsonObject = new JSONObject();
			jsonObject.put("error", "productName cann't be empty");
			jsonResponse = jsonObject.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();
			return;
		}
		try {
			jsonResponse = service.getProductByName(productName);
			if(!jsonResponse.isEmpty()) {
				writer.print(jsonResponse);
				writer.flush();
				writer.close();
				return;
			}
		} catch (Exception e) {

			jsonObject = new JSONObject();
			jsonObject.put("error", e.getMessage());
			jsonResponse = jsonObject.toJSONString();
			e.printStackTrace();
			writer.print(jsonResponse);
            writer.flush();
			writer.close();
			return ;
		
		}
		
	}
	

}
