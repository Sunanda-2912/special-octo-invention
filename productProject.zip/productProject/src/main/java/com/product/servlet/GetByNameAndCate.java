package com.product.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GetByNameAndCate extends HttpServlet {
	private static ProductServiceIntf service = ServiceFactory.getProducts();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		String jsonString = "";
		JSONObject jsonObject = new JSONObject();
		String productName = req.getParameter("productName");
		String productCategory = req.getParameter("productcategory");
		resp.setContentType("application/json");
		if (productName == null || productName.isEmpty()) {
			jsonObject.put("error", "productName can't be empty");
			jsonString = jsonObject.toJSONString();
			writer.print(jsonString);
			writer.flush();
			writer.close();
			return;
		}
		if (productCategory == null || productCategory.isEmpty()) {
			jsonObject.put("error", "product category can't be empty");
			jsonString = jsonObject.toJSONString();
			writer.print(jsonString);
			writer.flush();
			writer.close();
			return;
		}
		try {
			jsonString = service.getProuctDetByNameAndCategory(productName, productCategory);
			if (!jsonString.isEmpty()) {
				writer.print(jsonString);
				writer.flush();
				writer.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonString = jsonObject.toJSONString();
			writer.print(jsonString);
			writer.flush();
			writer.close();
			return;
		}
	}
}
