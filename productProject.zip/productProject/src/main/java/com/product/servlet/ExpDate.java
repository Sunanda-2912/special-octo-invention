package com.product.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ExpDate extends HttpServlet {
private static ProductServiceIntf service = ServiceFactory.getProducts();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		String jsonResponse ="";
		StringBuilder sb = new StringBuilder();
		resp.setContentType("application/json");
		String contentType = req.getContentType();
		if(contentType==null || !contentType.equals("application/json")) {
			jsonObject.put("error", "content type must be application/json");
			jsonResponse = jsonObject.toJSONString();
			writer.write(jsonResponse);
			writer.flush();
			writer.close();
			
		}
		BufferedReader reader = req.getReader();
		String line;
		while((line=reader.readLine())!=null) {
			sb.append(line);
		}
		JSONParser parser = new JSONParser();
		JSONObject jsonSb = new JSONObject();
		try {
			jsonSb = (JSONObject) parser.parse(sb.toString());
			
			String expDate = (String) jsonSb.get("expiryDate");
			
			if(expDate==null || expDate.isEmpty() ) {
				jsonObject.put("error", "expdate can't be empty");
				jsonArray.add(jsonObject);
			}if(!jsonArray.isEmpty()) {
				jsonResponse=jsonArray.toJSONString();
				writer.write(jsonResponse);
				writer.flush();
				writer.close();
				return;
			}
			
			jsonResponse = service.getProductsByExpDt(expDate);
			if(jsonResponse!=null) {
				writer.print(jsonResponse);
				writer.flush();
				writer.close();
				return;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonResponse = jsonObject.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();
			return;
		}
	}
}
