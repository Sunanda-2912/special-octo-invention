package com.product.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AllParam extends HttpServlet {

	private static ProductServiceIntf service = ServiceFactory.getProducts();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter writer = resp.getWriter();
		JSONObject errorMsg = null;
		JSONArray validateVal = new JSONArray();
		StringBuilder sb = new StringBuilder();
		String jsonResponse = "";
		resp.setContentType("application/json");

		String contentType = req.getContentType();
		if (contentType == null || !contentType.equals("application/json")) {
			errorMsg = new JSONObject();
			errorMsg.put("error", "content type must be application/json");
			validateVal.add(errorMsg);
			jsonResponse = validateVal.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();

		}

		BufferedReader reader = req.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}

		JSONParser parser = new JSONParser();
		JSONObject jsonSb = null;
		try {
			jsonSb = (JSONObject) parser.parse(sb.toString());

			String name = (String) jsonSb.get("productName");
			String category = (String) jsonSb.get("productCategory");
			String mfgDate = (String) jsonSb.get("manufactureDate");
			String expDate = (String) jsonSb.get("expiryDate");

			jsonResponse = service.getProductsByAllParam(name, category, mfgDate, expDate);
			System.out.println(jsonResponse);
			if (jsonResponse != null) {
				writer.write(jsonResponse);
				writer.flush();
				writer.close();
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			errorMsg = new JSONObject();
			errorMsg.put("error", e.getMessage());
			jsonResponse = errorMsg.toJSONString();
			writer.write(jsonResponse);
			writer.flush();
			writer.close();
			return;
		}

	}
}
