package com.product.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DescId extends HttpServlet {
	private static ProductServiceIntf service = ServiceFactory.getProducts();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter writer = resp.getWriter();
		String jsonResponse = " ";
		JSONObject errorMessage = new JSONObject();
		resp.setContentType("application.json");
		String firstId = req.getParameter("firstId");
		String lastId = req.getParameter("lastId");

		if (firstId == null || firstId.isEmpty()) {
			errorMessage.put("error", "firstid can't be empty");
			jsonResponse = errorMessage.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();
			return;

		}
		if (lastId == null || lastId.isEmpty()) {
			errorMessage.put("error", "lastId can't be empty");
			jsonResponse = errorMessage.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();
			return;
		}
		try {
			jsonResponse = service.getProducts(firstId, lastId);
			if (!jsonResponse.isEmpty()) {
				writer.print(jsonResponse);
				writer.flush();
				writer.close();
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
            errorMessage.put("error", e.getMessage());
            jsonResponse= errorMessage.toJSONString();
            writer.print(jsonResponse);
            writer.flush();
            writer.close();
            return;
		}
	}

}
