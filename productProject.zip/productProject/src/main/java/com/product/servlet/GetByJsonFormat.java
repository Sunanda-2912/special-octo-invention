package com.product.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.product.dto.ProductDto;
import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GetByJsonFormat extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static ProductServiceIntf service = ServiceFactory.getProducts();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		String jsonString = "";
		JSONObject jsonObject = new JSONObject();
		JSONArray validateValue = new JSONArray();
		StringBuilder sb = new StringBuilder();
		resp.setContentType("application/json");

		String contentType = req.getContentType();
		if (contentType == null || !contentType.equals("application/json")) {
			jsonObject.put("error", "Content type must be application/json");
			writer.print(jsonObject.toJSONString());
			writer.flush();
			writer.close();
			return;
		}

		BufferedReader reader = req.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}

		JSONParser parser = new JSONParser();
		try {
			JSONObject jsonSb = (JSONObject) parser.parse(sb.toString());
			String productName = (String) jsonSb.get("productName");
			String productCategory = (String) jsonSb.get("productCategory");

			if (productName == null || productName.isEmpty()) {
				JSONObject errorObject = new JSONObject();
				errorObject.put("error", "Product name can't be empty");
				validateValue.add(errorObject);
			}
			if (productCategory == null || productCategory.isEmpty()) {
				JSONObject errorObject = new JSONObject();
				errorObject.put("error", "Product category can't be empty");
				validateValue.add(errorObject);
			}

			if (!validateValue.isEmpty()) {
				jsonString = validateValue.toJSONString();
				writer.print(jsonString);
				writer.flush();
				writer.close();
				return;
			}

			ProductDto productDto = new ProductDto();
			productDto.setProductName(productName);
			productDto.setProductCategory(productCategory);

			jsonString = service.getProuctDetByNameAndCategory(productDto);
			System.out.println(jsonString);

			if (!jsonString.isEmpty()) {
				writer.print(jsonString);
				writer.flush();
				writer.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonString = jsonObject.toJSONString();
			writer.print(jsonString);
			writer.flush();
			writer.close();
		}
	}
}
