package com.product.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.product.service.ProductServiceIntf;
import com.product.service.ServiceFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DescIdJson extends HttpServlet {

	private static ProductServiceIntf service = ServiceFactory.getProducts();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		JSONObject jsonError = new JSONObject();
		String jsonResponse = "";
		JSONArray validateValue = new JSONArray();
		StringBuilder sb = new StringBuilder();
		resp.setContentType("application/json");
		String contentType = req.getContentType();
		if (contentType == null || !contentType.equals("application/json")) {
			jsonError.put("error", "content type must be application/json");
			jsonResponse = jsonError.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();
			return;

		}
		BufferedReader reader = req.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}

		JSONParser parser = new JSONParser();
		JSONObject jsonSb = null;
		try {
			jsonSb = (JSONObject) parser.parse(sb.toString());

			String firstId = (String) jsonSb.get("firstId");
			String lastId = (String) jsonSb.get("lastId");

			if (firstId == null || firstId.isEmpty()) {
				jsonError.put("error", "firstid can't be empty");
				validateValue.add(jsonError);

			}
			if (lastId == null || lastId.isEmpty()) {
				jsonError.put("error", "lastId can't be empty");
				validateValue.add(jsonError);

			}

			if (!validateValue.isEmpty()) {
				jsonResponse = validateValue.toJSONString();
				writer.print(jsonResponse);
				writer.flush();
				writer.close();

			}

			jsonResponse = service.getProducts(firstId, lastId);
			if (jsonResponse != null) {
				writer.print(jsonResponse);
				writer.flush();
				writer.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			jsonError.put("error", e.getMessage());
			jsonResponse = jsonError.toJSONString();
			writer.print(jsonResponse);
			writer.flush();
			writer.close();
			return;
		}

	}

}
