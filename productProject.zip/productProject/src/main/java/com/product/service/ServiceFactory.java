package com.product.service;

public class ServiceFactory {
private static ProductServiceIntf productService;
static {
	productService = new ProductServiceImpl();
}
public  static ProductServiceIntf getProducts() {
	return productService;
}
}
