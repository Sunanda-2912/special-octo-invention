package com.product.service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.json.simple.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.product.bean.Product;
import com.product.dao.DaoFactory;
import com.product.dao.ProductDaoIntf;
import com.product.dto.ProductDto;

import jakarta.servlet.http.HttpServletResponse;

public class ProductServiceImpl implements ProductServiceIntf {

	private static ProductDaoIntf daoImpl = DaoFactory.getProductDet();

	@Override
	public String insertProductDet(ProductDto dto) {
		String jsonString = " ";
		JSONObject jsonObject = new JSONObject();
		try {
			int insertProductDet = daoImpl.insertProductDet(dto);
			int insertProductPrice = daoImpl.insertProductPrice(dto);
			if (insertProductDet != 0 && insertProductPrice != 0) {
				jsonObject.put("msg", "insertion successful");
				jsonString = jsonObject.toJSONString();
			}
		} catch (Exception e) {
			String jsonStringErr = "";
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonStringErr = jsonObject.toJSONString();
			return jsonStringErr;
		}
		return jsonString;
	}

	@Override
	public String getProuctDetByNameAndCategory(ProductDto productDto) {

		List<ProductDto> products = new ArrayList();
		String jsonString = "";
		JSONObject jsonObject = new JSONObject();
		try {
			products = daoImpl.getProductNameAndCategory(productDto);
			if (products != null && !products.isEmpty()) {
				Gson gson = new Gson();
				jsonString = gson.toJson(products);
				// return jsonString;
			} else {
				jsonObject.put("error", "products list can't be empty");
				jsonString = jsonObject.toJSONString();
				return jsonString;
			}
		} catch (Exception e) {

			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonString = jsonObject.toJSONString();
			return jsonString;
		}
		return jsonString;
	}

	@Override
	public String getProductByName(String productName) {

		List<Product> products = new ArrayList();
		String jsonString = "";
		JSONObject jsonObject = new JSONObject();
		try {
			products = daoImpl.getProductDetail(productName);
			if (products != null && !products.isEmpty()) {
				Gson gson = new Gson();
				jsonString = gson.toJson(products);
			} else {
				jsonObject.put("error", "products can't be empty");
				jsonString = jsonObject.toJSONString();
				return jsonString;
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonString = jsonObject.toJSONString();
			return jsonString;
		}
		return jsonString;

	}

	@Override
	public String getProuctDetByNameAndCategory(String productName, String productCategory) {

		List<Product> products = new ArrayList();
		String jsonString = "";
		JSONObject json = new JSONObject();
		try {
			products = daoImpl.getProductNameAndCategory(productName, productCategory);
			if (products != null && !products.isEmpty()) {
				Gson gson = new Gson();
				jsonString = gson.toJson(products);
			} else {
				json.put("error", "products list can't be empty");
				jsonString = json.toJSONString();
				return jsonString;
			}
		} catch (Exception e) {

			e.printStackTrace();
			json.put("error", e.getMessage());
			jsonString = json.toJSONString();
			return jsonString;
		}
		return jsonString;
	}

	@Override
	public String getProducts(String firstId, String lastId) {

		List<Product> products = new ArrayList<Product>();
		String jsonString = "";
		JSONObject jsonObject = null;
		try {
			products = daoImpl.getProducts(firstId, lastId);
			if (products != null && !products.isEmpty()) {
				Gson gson = new Gson();
				jsonString = gson.toJson(products);
			} else {
				jsonObject.put("error", "product list cannot be null");
				jsonString = jsonObject.toJSONString();
				System.out.println(jsonString);
				// return jsonString;
			}
		} catch (Exception e) {

			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonString = jsonObject.toJSONString();
			return jsonString;

		}

		return jsonString;
	}

	@Override
	public String getProductsByMfgDate(String date) {
		List<ProductDto> products = new ArrayList<>();
		String jsonResponse = "";
		JSONObject jsonObject = new JSONObject();

		try {

			String startDtTime = date + " 00:00:00";
			String endDtTime = date + " 23:59:59";

			Timestamp startTime = Timestamp.valueOf(startDtTime);
			Timestamp endTime = Timestamp.valueOf(endDtTime);

			products = daoImpl.getProductsByMfgDate(startTime, endTime);

			if (products != null && !products.isEmpty()) {
				Gson gson = new Gson();
				jsonResponse = gson.toJson(products);
			} else {
				jsonObject.put("error", "Product list can't be empty");
				jsonResponse = jsonObject.toJSONString();
				return jsonResponse;
			}
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonResponse = jsonObject.toJSONString();
			return jsonResponse;
		}

		return jsonResponse;
	}

	@Override
	public String getProductsByExpDt(String date) {

		List<ProductDto> products = new ArrayList<ProductDto>();
		String jsonResponse = "";
		JSONObject jsonObject = new JSONObject();
		try {
			String startDtTime = date + " 00:00:00";
			String endDtTime = date + " 23:59:59";

			Timestamp startTime = Timestamp.valueOf(startDtTime);
			Timestamp endTime = Timestamp.valueOf(endDtTime);

			products = daoImpl.getProduct(startTime, endTime);
			if (products != null && !products.isEmpty()) {
				Gson gson = new Gson();
				jsonResponse = gson.toJson(products);

			}
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			jsonResponse = jsonObject.toJSONString();
			return jsonResponse;
		}
		return jsonResponse;
	}

	@Override
	public String getProductsByAllParam(String productName, String productCategory, String mfgDate, String expDate) {

		List<ProductDto> products = new ArrayList<ProductDto>();
		String jsonResponse = "";
		JSONObject jsonObject = new JSONObject();
		String prodNameParam = "";
		String prodCatParam = "";
		Timestamp startTime = null;
		Timestamp endTime = null;
		Timestamp startTime2 = null;
		Timestamp endTime2 = null;
		Boolean searchFlag = false;

		try {
			if (!productName.isEmpty()) {
				prodNameParam = productName;
				searchFlag = true;
			}
			if (!productCategory.isEmpty()) {
				prodCatParam = productCategory;
				searchFlag = true;
			}
			if (!mfgDate.isEmpty()) {
				String startDtTime = mfgDate + " 00:00:00";
				String endDtTime = mfgDate + " 23:59:59";
				startTime = Timestamp.valueOf(startDtTime);
				endTime = Timestamp.valueOf(endDtTime);
				searchFlag = true;

			}

			if (!expDate.isEmpty()) {
				String startDtTime1 = expDate + " 00:00:00";
				String endDtTime1 = expDate + " 23:59:59";
				startTime2 = Timestamp.valueOf(startDtTime1);
				endTime2 = Timestamp.valueOf(endDtTime1);
				searchFlag = true;

			}

			if (searchFlag == true) {
				products = daoImpl.getProducts(prodNameParam, prodCatParam, startTime, endTime, startTime2, endTime2);
				if (products != null && !products.isEmpty()) {
					Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss.SS").create();
					jsonResponse = gson.toJson(products);
				}

			} else {
				products = daoImpl.getAllProducts();
				if (products != null && !products.isEmpty()) {
					Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss.SS").create();
					jsonResponse = gson.toJson(products);
				}
			}
			System.out.println(jsonResponse);
		} catch (Exception e) {

			e.printStackTrace();
			jsonObject.put("error", e.getMessage());
			return jsonObject.toJSONString();
		}
		return jsonResponse;
	}
}
