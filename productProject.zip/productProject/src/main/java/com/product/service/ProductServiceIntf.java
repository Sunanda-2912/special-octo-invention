package com.product.service;

import java.sql.Timestamp;
import java.util.List;

import com.product.bean.Product;
import com.product.dto.ProductDto;

public interface ProductServiceIntf {
 
	public String insertProductDet(ProductDto dto);
	public String getProductByName(String  productName);
	public String getProuctDetByNameAndCategory(String productName, String productCategory);
	public String getProuctDetByNameAndCategory(ProductDto productDto);
	public String getProducts(String firstId , String lastId);
    public String getProductsByMfgDate(String date);
    public String getProductsByExpDt(String date);
    public String getProductsByAllParam(String  productName,String productCategory,String date,String date1);


}
